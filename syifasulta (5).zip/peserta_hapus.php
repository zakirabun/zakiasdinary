<?php
include "cek_admin.php";
include "koneksi.php";

$id = (int) $_GET['id'];
$ekskul = (int) $_GET['ekskul'];
$stmt = mysqli_prepare($conn, "DELETE FROM pendaftar WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

header("Location: peserta.php?id=$ekskul");
exit;
