<?php
// Cek apakah username sudah dipakai di tabel admin, guru, atau siswa.
// $kecuali_* = id yang dikecualikan saat edit akun sendiri.
function username_dipakai($conn, $username, $kecuali_guru = 0, $kecuali_siswa = 0, $kecuali_admin = 0) {
    $cek = [['admin', $kecuali_admin], ['guru', $kecuali_guru], ['siswa', $kecuali_siswa]];
    foreach ($cek as [$tabel, $kecuali]) {
        $stmt = mysqli_prepare($conn, "SELECT id FROM $tabel WHERE username = ? AND id <> ?");
        mysqli_stmt_bind_param($stmt, "si", $username, $kecuali);
        mysqli_stmt_execute($stmt);
        if (mysqli_stmt_get_result($stmt)->num_rows > 0) return true;
    }
    return false;
}

function nis_dipakai($conn, $nis, $kecuali_siswa = 0) {
    $stmt = mysqli_prepare($conn, "SELECT id FROM siswa WHERE nis = ? AND nis <> '' AND id <> ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "si", $nis, $kecuali_siswa);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt)->num_rows > 0;
}

// Galeri room hanya untuk anggota ekskul serta admin/guru.
function boleh_akses_room($conn, $ekskul_id) {
    if (!isset($_SESSION['role'])) return false;
    if (in_array($_SESSION['role'], ['admin', 'guru'], true)) return true;
    if ($_SESSION['role'] !== 'siswa') return false;
    $stmt = mysqli_prepare($conn, "SELECT 1 FROM pendaftar p
                                   JOIN siswa s ON s.nis = p.nis
                                   WHERE s.username = ? AND s.nis <> '' AND p.ekskul_id = ?
                                     AND (SELECT COUNT(*) FROM siswa s2 WHERE s2.nis = s.nis) = 1
                                   LIMIT 1");
    mysqli_stmt_bind_param($stmt, "si", $_SESSION['user'], $ekskul_id);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt)->num_rows > 0;
}

// Upload mengikuti aturan akses galeri room.
function boleh_upload_room($conn, $ekskul_id) {
    return boleh_akses_room($conn, $ekskul_id);
}

// Boleh hapus media ini? Admin: semua. Lainnya: hanya miliknya sendiri.
function boleh_hapus_media($m) {
    if (!isset($_SESSION['role'])) return false;
    return $_SESSION['role'] === 'admin' || ($_SESSION['user'] === $m['pengunggah'] && $_SESSION['role'] === $m['peran']);
}
