<?php
session_start();
include "koneksi.php";

$error = "";
$next = $_GET['next'] ?? '';
$redirectNext = preg_match('/^room\.php\?id=\d+$/', $next) ? $next : '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);

    // Cek di tabel admin dulu, lalu tabel guru
    foreach (['admin', 'guru', 'siswa'] as $role) {
        $stmt = mysqli_prepare($conn, "SELECT password FROM $role WHERE username = ?");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if ($row && password_verify($_POST['password'], $row['password'])) {
            session_regenerate_id(true);
            $_SESSION['role'] = $role;
            $_SESSION['user'] = $username;
            header("Location: " . ($redirectNext !== '' ? $redirectNext : ($role === 'siswa' ? 'profil.php' : 'admin.php')));
            exit;
        }
    }
    $error = "Username atau password salah.";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container" style="max-width:400px">
    <h1>Login</h1>
    <p class="sub">Admin, guru, dan siswa.</p>
    <?php if ($error) { ?><div class="alert err"><?= $error ?></div><?php } ?>
    <form method="post">
        <label>Username</label>
        <input type="text" name="username" required>
        <label>Password</label>
        <input type="password" name="password" required>
        <br><br>
        <button type="submit">Masuk</button>
        <a href="index.php" class="btn abu">Kembali</a>
        <a href="register.php" class="btn abu">Buat akun siswa</a>
        <br><br><a href="reset_admin.php">Lupa password admin / buat akun admin?</a>
    </form>
</div>
</body>
</html>
