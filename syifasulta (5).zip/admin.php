<?php
include "cek_staff.php";
include "koneksi.php";
$hasil = mysqli_query($conn, "SELECT e.*, (SELECT COUNT(*) FROM pendaftar p WHERE p.ekskul_id = e.id) AS terisi FROM ekskul e ORDER BY e.nama");
$ekskul = mysqli_fetch_all($hasil, MYSQLI_ASSOC);
$jumlahPeserta = 0;
$jumlahSlot = 0;
foreach ($ekskul as $item) {
    $jumlahPeserta += (int) $item['terisi'];
    $jumlahSlot += max(0, (int) $item['kuota'] - (int) $item['terisi']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard <?= $_SESSION['role'] === 'admin' ? 'Admin' : 'Guru' ?> — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <?php $isAdmin = $_SESSION['role'] === 'admin'; ?>
    <h1>Dashboard <?= $isAdmin ? 'Admin' : 'Guru' ?></h1>
    <p class="sub">Masuk sebagai <?= htmlspecialchars($_SESSION['user']) ?> (<?= $_SESSION['role'] ?>)</p>
    <div class="nav">
        <a href="index.php" class="brand-mark"><span class="brand-symbol">C</span><span>Clubify</span></a>
        <span class="nav-spacer"></span>
        <?php if ($isAdmin) { ?>
        <a href="ekskul_form.php" class="btn">+ Tambah Ekskul</a>
        <a href="pengguna.php" class="btn edit">Daftar User</a>
        <?php } ?>
        <a href="upload.php" class="btn">Upload Media</a>
        <a href="galeri.php" class="btn abu">Galeri</a>
        <a href="index.php" class="btn abu">Halaman Publik</a>
        <a href="logout.php" class="btn hapus">Logout</a>
    </div>

    <div class="stat-grid dashboard-stats">
        <div class="stat-card"><span class="stat-icon stat-violet">✦</span><div><strong><?= count($ekskul) ?></strong><span>Total ekskul</span></div></div>
        <div class="stat-card"><span class="stat-icon stat-pink">◎</span><div><strong><?= $jumlahPeserta ?></strong><span>Total peserta</span></div></div>
        <div class="stat-card"><span class="stat-icon stat-mint">＋</span><div><strong><?= $jumlahSlot ?></strong><span>Kursi tersedia</span></div></div>
    </div>
    <div class="section-heading dashboard-heading"><div><span class="eyebrow">KELOLA KEGIATAN</span><h2>Daftar ekstrakurikuler</h2></div></div>
    <table>
        <thead><tr><th>Ekskul</th><th>Pembina</th><th>Jadwal</th><th>Peserta</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($ekskul as $e) { ?>
        <tr>
            <td><?= htmlspecialchars($e['nama']) ?></td>
            <td><?= htmlspecialchars($e['pembina']) ?></td>
            <td><?= htmlspecialchars($e['jadwal']) ?></td>
            <td><span class="table-count"><?= (int) $e['terisi'] ?> / <?= (int) $e['kuota'] ?></span></td>
            <td>
                <a class="btn abu" href="room.php?id=<?= $e['id'] ?>">Room</a>
                <a class="btn" href="peserta.php?id=<?= $e['id'] ?>">Peserta</a>
                <?php if ($isAdmin) { ?>
                <a class="btn edit" href="ekskul_form.php?id=<?= $e['id'] ?>">Edit</a>
                <a class="btn hapus" href="ekskul_hapus.php?id=<?= $e['id'] ?>" onclick="return confirm('Hapus ekskul beserta semua pesertanya?')">Hapus</a>
                <?php } ?>
            </td>
        </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
</body>
</html>
