<?php
// Kode rahasia untuk halaman reset_admin.php (lupa password admin). GANTI dengan kode milikmu sendiri.
if (!defined('KODE_RESET')) define('KODE_RESET', '090610');

$conn = mysqli_connect("localhost", "root", "", "db_ekskul");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Buat tabel guru kalau belum ada (akun guru dibuat oleh admin)
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS guru (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    dibuat DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// Buat tabel siswa (siswa mendaftar sendiri)
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS siswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    nis VARCHAR(20) NOT NULL DEFAULT '',
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    kelas VARCHAR(20) NOT NULL,
    foto VARCHAR(255) NULL,
    dibuat DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// Database lama: tambahkan kolom nis ke tabel siswa kalau belum ada
$kol = mysqli_query($conn, "SHOW COLUMNS FROM siswa LIKE 'nis'");
if (mysqli_num_rows($kol) == 0) {
    mysqli_query($conn, "ALTER TABLE siswa ADD COLUMN nis VARCHAR(20) NOT NULL DEFAULT '' AFTER nama");
}

// Buat tabel media (foto, video, musik) kalau belum ada
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS media (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(150) NOT NULL,
    tipe ENUM('foto','video','musik') NOT NULL,
    file VARCHAR(255) NOT NULL,
    ekskul_id INT NULL,
    pengunggah VARCHAR(50) NOT NULL,
    peran VARCHAR(10) NOT NULL,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ekskul_id) REFERENCES ekskul(id) ON DELETE SET NULL
)");

// Buat akun admin awal kalau tabel admin masih kosong
$cek = mysqli_query($conn, "SELECT COUNT(*) AS jml FROM admin");
if (mysqli_fetch_assoc($cek)['jml'] == 0) {
    $hash = password_hash("zakiasdinary", PASSWORD_DEFAULT);
    $stmt = mysqli_prepare($conn, "INSERT INTO admin (username, password) VALUES ('zaki admin', ?)");
    mysqli_stmt_bind_param($stmt, "s", $hash);
    mysqli_stmt_execute($stmt);
}