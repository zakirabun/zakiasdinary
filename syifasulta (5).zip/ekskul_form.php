<?php
include "cek_admin.php";
include "koneksi.php";

$data = ['id' => '', 'nama' => '', 'pembina' => '', 'jadwal' => '', 'kuota' => 20];

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $q = mysqli_query($conn, "SELECT * FROM ekskul WHERE id = $id");
    if ($row = mysqli_fetch_assoc($q)) {
        $data = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id      = (int) $_POST['id'];
    $nama    = $_POST['nama'];
    $pembina = $_POST['pembina'];
    $jadwal  = $_POST['jadwal'];
    $kuota   = (int) $_POST['kuota'];

    if ($id > 0) {
        $stmt = mysqli_prepare($conn, "UPDATE ekskul SET nama=?, pembina=?, jadwal=?, kuota=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "sssii", $nama, $pembina, $jadwal, $kuota, $id);
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO ekskul (nama, pembina, jadwal, kuota) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sssi", $nama, $pembina, $jadwal, $kuota);
    }
    mysqli_stmt_execute($stmt);
    header("Location: admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $data['id'] ? 'Edit' : 'Tambah' ?> Ekskul — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1><?= $data['id'] ? 'Edit' : 'Tambah' ?> Ekskul</h1>
    <form method="post">
        <input type="hidden" name="id" value="<?= $data['id'] ?>">

        <label>Nama Ekskul</label>
        <input type="text" name="nama" value="<?= htmlspecialchars($data['nama']) ?>" required>

        <label>Pembina</label>
        <input type="text" name="pembina" value="<?= htmlspecialchars($data['pembina']) ?>" required>

        <label>Jadwal</label>
        <input type="text" name="jadwal" value="<?= htmlspecialchars($data['jadwal']) ?>" placeholder="contoh: Jumat, 14.00" required>

        <label>Kuota</label>
        <input type="number" name="kuota" min="1" value="<?= $data['kuota'] ?>" required>

        <br><br>
        <button type="submit">Simpan</button>
        <a href="admin.php" class="btn abu">Batal</a>
    </form>
</div>
</body>
</html>
