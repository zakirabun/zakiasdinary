<?php
session_start();
include "koneksi.php";
$hasil = mysqli_query($conn, "SELECT e.*,
                                     (SELECT COUNT(*) FROM pendaftar p WHERE p.ekskul_id = e.id) AS terisi
                              FROM ekskul e ORDER BY e.nama");
$ekskul = mysqli_fetch_all($hasil, MYSQLI_ASSOC);
$jumlahPeserta = 0;
$jumlahSlot = 0;
$jumlahEkskul = count($ekskul);
foreach ($ekskul as $item) {
    $jumlahPeserta += (int) $item['terisi'];
    $jumlahSlot += max(0, (int) $item['kuota'] - (int) $item['terisi']);
}
$role = $_SESSION['role'] ?? '';
$halamanAkun = $role === 'siswa' ? 'profil.php' : ($role !== '' ? 'admin.php' : 'login.php');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Clubify — Temukan kegiatanmu</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="nav">
        <a href="index.php" class="brand-mark"><span class="brand-symbol">C</span><span>Clubify</span></a>
        <span class="nav-spacer"></span>
        <a href="#jelajahi" class="btn abu">Jelajahi</a>
        <a href="galeri.php" class="btn abu">Galeri</a>
        <?php if ($role !== '') { ?>
            <a href="<?= $halamanAkun ?>" class="btn">Akun saya</a>
        <?php } else { ?>
            <a href="login.php" class="btn abu">Masuk</a>
            <a href="register.php" class="btn">Buat akun</a>
        <?php } ?>
    </div>

    <section class="hero">
        <div class="hero-copy">
            <span class="eyebrow"><span class="eyebrow-dot"></span> RUANG UNTUK BERTUMBUH</span>
            <h1>Temukan hal yang<br><span class="text-gradient">kamu sukai.</span></h1>
            <p class="hero-description">Mulai perjalanan baru, temukan teman satu minat, dan kembangkan potensimu lewat kegiatan ekstrakurikuler.</p>
            <a href="#jelajahi" class="btn hero-cta">Temukan ekskul <span aria-hidden="true">↓</span></a>
            <span class="hero-note">Pilih kegiatanmu. Ceritakan versimu.</span>
        </div>
        <div class="hero-art" aria-hidden="true">
            <div class="hero-orbit orbit-one"></div>
            <div class="hero-orbit orbit-two"></div>
            <div class="hero-center"><span>✨</span><strong>Temukan<br>versimu</strong></div>
            <div class="float-card float-card-top"><span class="float-icon">✦</span><span><b>Minat baru</b><small>dimulai di sini</small></span></div>
            <div class="float-card float-card-bottom"><span class="float-icon">♡</span><span><b>Teman baru</b><small>punya minat yang sama</small></span></div>
        </div>
    </section>

    <section class="stat-grid" aria-label="Ringkasan ekstrakurikuler">
        <div class="stat-card"><span class="stat-icon stat-violet">✦</span><div><strong><?= $jumlahEkskul ?></strong><span>Pilihan ekskul</span></div></div>
        <div class="stat-card"><span class="stat-icon stat-pink">◎</span><div><strong><?= $jumlahPeserta ?></strong><span>Siswa bergabung</span></div></div>
        <div class="stat-card"><span class="stat-icon stat-mint">＋</span><div><strong><?= $jumlahSlot ?></strong><span>Kursi tersedia</span></div></div>
    </section>

    <section id="jelajahi" class="explore-section">
        <div class="section-heading">
            <div><span class="eyebrow">MULAI PETUALANGANMU</span><h2>Jelajahi ekskul</h2><p class="sub">Pilih kegiatan yang paling sesuai dengan minatmu.</p></div>
            <a href="daftar.php" class="text-link">Cara mendaftar <span aria-hidden="true">→</span></a>
        </div>
        <div class="explore-tools">
            <label class="search-box"><span aria-hidden="true">⌕</span><input id="ekskul-search" type="search" placeholder="Cari nama, pembina, atau jadwal..." aria-label="Cari ekstrakurikuler"></label>
            <div class="filter-group" role="group" aria-label="Filter ekstrakurikuler">
                <button type="button" class="filter-chip is-active" data-filter="all" aria-pressed="true">Semua <span><?= $jumlahEkskul ?></span></button>
                <button type="button" class="filter-chip" data-filter="available" aria-pressed="false">Masih tersedia</button>
            </div>
        </div>
        <div class="grid explore-grid" id="ekskul-grid">
            <?php foreach ($ekskul as $e) {
                $sisa = max(0, (int) $e['kuota'] - (int) $e['terisi']);
                $persen = (int) $e['kuota'] > 0 ? min(100, round($e['terisi'] / $e['kuota'] * 100)) : 0;
                $searchText = mb_strtolower($e['nama'] . ' ' . $e['pembina'] . ' ' . $e['jadwal'], 'UTF-8'); ?>
            <article class="card ekskul-card" data-search="<?= htmlspecialchars($searchText, ENT_QUOTES, 'UTF-8') ?>" data-available="<?= $sisa > 0 ? '1' : '0' ?>">
                <a class="activity-cover club-cover club-cover-<?= (int) $e['id'] % 4 ?>" href="room.php?id=<?= (int) $e['id'] ?>" aria-label="Galeri privat <?= htmlspecialchars($e['nama']) ?>">
                    <span class="cover-ornament" aria-hidden="true">✳</span>
                    <span class="cover-caption"><small>CLUBIFY · GALERI PRIVAT</small><strong><?= htmlspecialchars($e['nama']) ?></strong><span>Anggota dapat melihat cerita kegiatan</span></span>
                    <span class="cover-lock" aria-hidden="true">⌑</span>
                </a>
                <div class="card-topline"><span class="activity-mark" aria-hidden="true">✦</span><span class="status-pill <?= $sisa > 0 ? 'status-open' : 'status-full' ?>"><?= $sisa > 0 ? 'Pendaftaran dibuka' : 'Kuota penuh' ?></span></div>
                <h3><?= htmlspecialchars($e['nama']) ?></h3>
                <p class="meta">Dibina oleh <strong><?= htmlspecialchars($e['pembina']) ?></strong></p>
                <div class="schedule-line"><span aria-hidden="true">◷</span><?= htmlspecialchars($e['jadwal']) ?></div>
                <div class="capacity-row"><span>Kapasitas</span><strong><?= (int) $e['terisi'] ?><span> / <?= (int) $e['kuota'] ?></span></strong></div>
                <div class="bar" role="progressbar" aria-label="Kapasitas <?= htmlspecialchars($e['nama']) ?>" aria-valuemin="0" aria-valuemax="<?= max(1, (int) $e['kuota']) ?>" aria-valuenow="<?= min((int) $e['terisi'], (int) $e['kuota']) ?>"><i style="width:<?= $persen ?>%"></i></div>
                <div class="card-actions">
                    <?php if ($sisa > 0) { ?>
                        <a class="btn" href="daftar.php?id=<?= (int) $e['id'] ?>">Lihat &amp; daftar <span aria-hidden="true">→</span></a>
                    <?php } else { ?>
                        <span class="btn nonaktif">Kuota penuh</span>
                    <?php } ?>
                    <a class="btn abu" href="room.php?id=<?= (int) $e['id'] ?>">Galeri privat <span aria-hidden="true">⌑</span></a>
                </div>
            </article>
            <?php } ?>
            <div class="empty-state" id="empty-state" hidden><span aria-hidden="true">⌕</span><h3>Belum ada yang cocok</h3><p>Coba kata kunci lain atau ubah filter pilihanmu.</p></div>
        </div>
    </section>
    <footer class="site-footer"><span>Clubify</span><span>Temukan minatmu, tumbuh bersama.</span></footer>
</div>
<script>
(() => {
    const search = document.getElementById('ekskul-search');
    const cards = Array.from(document.querySelectorAll('.ekskul-card'));
    const buttons = Array.from(document.querySelectorAll('.filter-chip'));
    const emptyState = document.getElementById('empty-state');
    let activeFilter = 'all';

    function updateCards() {
        const query = search.value.trim().toLocaleLowerCase('id');
        let visible = 0;
        cards.forEach((card) => {
            const matchesSearch = card.dataset.search.includes(query);
            const matchesFilter = activeFilter === 'all' || card.dataset.available === '1';
            card.hidden = !matchesSearch || !matchesFilter;
            if (!card.hidden) visible++;
        });
        emptyState.hidden = visible > 0;
    }

    search.addEventListener('input', updateCards);
    buttons.forEach((button) => button.addEventListener('click', () => {
        activeFilter = button.dataset.filter;
        buttons.forEach((item) => {
            const selected = item === button;
            item.classList.toggle('is-active', selected);
            item.setAttribute('aria-pressed', String(selected));
        });
        updateCards();
    }));
})();
</script>
</body>
</html>
