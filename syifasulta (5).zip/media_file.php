<?php
session_start();
include "koneksi.php";
include "fungsi.php";

if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'HEAD'], true)) {
    header("Allow: GET, HEAD");
    http_response_code(405);
    exit;
}

$id = (int) ($_GET['id'] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT id, file, ekskul_id, tipe FROM media WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$media = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$media) {
    http_response_code(404);
    exit;
}

if ($media['ekskul_id'] !== null && !boleh_akses_room($conn, (int) $media['ekskul_id'])) {
    http_response_code(403);
    exit;
}

$filename = basename($media['file']);
$path = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $filename;
if ($filename === '' || !is_file($path)) {
    http_response_code(404);
    exit;
}

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
$allowed = [
    'foto' => ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
    'video' => ['video/mp4', 'video/webm', 'video/x-m4v', 'video/quicktime'],
    'musik' => ['audio/mpeg', 'audio/mp3', 'audio/mp4', 'audio/ogg', 'application/ogg', 'audio/wav', 'audio/x-wav', 'audio/vnd.wave'],
];
if (!in_array($mime, $allowed[$media['tipe']] ?? [], true)) {
    http_response_code(415);
    exit;
}

$size = filesize($path);
$start = 0;
$end = $size - 1;
$partial = false;
if (isset($_SERVER['HTTP_RANGE'])) {
    if (!preg_match('/^bytes=(\d*)-(\d*)$/', $_SERVER['HTTP_RANGE'], $range) || ($range[1] === '' && $range[2] === '')) {
        header("Content-Range: bytes */$size");
        http_response_code(416);
        exit;
    }

    if ($range[1] === '') {
        $length = min((int) $range[2], $size);
        $start = $size - $length;
    } else {
        $start = (int) $range[1];
        $end = $range[2] === '' ? $end : (int) $range[2];
    }

    if ($start > $end || $start >= $size) {
        header("Content-Range: bytes */$size");
        http_response_code(416);
        exit;
    }
    $end = min($end, $size - 1);
    $partial = true;
}

$handle = fopen($path, 'rb');
if ($handle === false) {
    http_response_code(404);
    exit;
}

session_write_close();
header("Content-Type: $mime");
header("X-Content-Type-Options: nosniff");
header("Cache-Control: private, no-store");
header("Accept-Ranges: bytes");
header("Content-Length: " . ($end - $start + 1));
if ($partial) {
    http_response_code(206);
    header("Content-Range: bytes $start-$end/$size");
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    fseek($handle, $start);
    $remaining = $end - $start + 1;
    while ($remaining > 0 && !feof($handle)) {
        $chunk = fread($handle, min(8192, $remaining));
        if ($chunk === false || $chunk === '') break;
        echo $chunk;
        $remaining -= strlen($chunk);
    }
}
fclose($handle);
