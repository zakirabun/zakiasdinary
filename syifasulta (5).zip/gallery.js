(() => {
    const formatTime = (seconds) => {
        if (!Number.isFinite(seconds) || seconds < 0) return '--:--';
        const minutes = Math.floor(seconds / 60);
        const remainder = Math.floor(seconds % 60);
        return `${minutes}:${String(remainder).padStart(2, '0')}`;
    };

    const players = Array.from(document.querySelectorAll('[data-audio-player]'));
    players.forEach((player) => {
        const audio = player.querySelector('audio');
        const controls = player.querySelector('.audio-controls');
        const toggle = player.querySelector('.audio-toggle');
        const toggleIcon = player.querySelector('.audio-toggle-icon');
        const toggleLabel = player.querySelector('.audio-toggle-label');
        const currentTime = player.querySelector('.audio-current');
        const duration = player.querySelector('.audio-duration');
        const seek = player.querySelector('input[type="range"]');
        const error = player.querySelector('.media-error');
        const wave = player.querySelector('.audio-wave');

        if (!audio || !controls || !toggle || !seek) return;

        wave.replaceChildren(...Array.from({ length: 36 }, (_, index) => {
            const bar = document.createElement('span');
            const height = 22 + Math.abs(Math.sin(index * 1.73) * 62);
            bar.style.setProperty('--wave-height', `${height}%`);
            return bar;
        }));

        const updateState = () => {
            const isPlaying = !audio.paused;
            toggleIcon.textContent = isPlaying ? 'Ⅱ' : '▶';
            toggleLabel.textContent = isPlaying ? 'Pause' : 'Putar';
            toggle.setAttribute('aria-label', isPlaying ? 'Jeda audio' : 'Putar audio');
            player.classList.toggle('is-playing', isPlaying);
        };

        const updateProgress = () => {
            currentTime.textContent = formatTime(audio.currentTime);
            duration.textContent = formatTime(audio.duration);
            seek.disabled = !Number.isFinite(audio.duration) || audio.duration <= 0;
            seek.value = seek.disabled ? '0' : String(Math.round((audio.currentTime / audio.duration) * 1000));
            seek.style.setProperty('--seek-progress', `${seek.value / 10}%`);
        };

        audio.controls = false;
        audio.classList.add('audio-enhanced');
        controls.hidden = false;
        updateProgress();

        toggle.addEventListener('click', () => {
            if (audio.paused) {
                players.forEach((other) => {
                    const otherAudio = other.querySelector('audio');
                    if (otherAudio && otherAudio !== audio) otherAudio.pause();
                });
                const playRequest = audio.play();
                if (playRequest && typeof playRequest.catch === 'function') {
                    playRequest.catch(() => {
                        error.hidden = false;
                    });
                }
            } else {
                audio.pause();
            }
        });

        seek.addEventListener('input', () => {
            if (!seek.disabled) {
                audio.currentTime = (Number(seek.value) / 1000) * audio.duration;
                updateProgress();
            }
        });

        audio.addEventListener('loadedmetadata', updateProgress);
        audio.addEventListener('durationchange', updateProgress);
        audio.addEventListener('timeupdate', updateProgress);
        audio.addEventListener('play', () => {
            error.hidden = true;
            updateState();
        });
        audio.addEventListener('pause', updateState);
        audio.addEventListener('ended', () => {
            updateState();
            updateProgress();
        });
        audio.addEventListener('error', () => {
            error.hidden = false;
            toggle.disabled = true;
        });
    });

    document.querySelectorAll('.gallery-video').forEach((video) => {
        const error = video.closest('.video-stage')?.querySelector('.media-error');
        if (!error) return;
        video.addEventListener('error', () => {
            error.hidden = false;
        });
        video.addEventListener('loadeddata', () => {
            error.hidden = true;
        });
    });

    const lightbox = document.getElementById('photo-lightbox');
    if (lightbox && typeof lightbox.showModal === 'function') {
        const image = lightbox.querySelector('img');
        const caption = lightbox.querySelector('p');
        document.querySelectorAll('[data-lightbox-title]').forEach((link) => {
            link.addEventListener('click', (event) => {
                event.preventDefault();
                image.src = link.href;
                image.alt = link.dataset.lightboxTitle;
                caption.textContent = link.dataset.lightboxTitle;
                lightbox.showModal();
            });
        });
        lightbox.addEventListener('click', (event) => {
            if (event.target === lightbox) lightbox.close();
        });
        lightbox.addEventListener('close', () => {
            image.removeAttribute('src');
        });
    }
})();
