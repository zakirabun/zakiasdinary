<?php
include "cek_login.php";
include "koneksi.php";

if ($_SESSION['role'] !== 'siswa') {
    http_response_code(403);
    exit;
}

$stmt = mysqli_prepare($conn, "SELECT foto FROM siswa WHERE username = ?");
mysqli_stmt_bind_param($stmt, "s", $_SESSION['user']);
mysqli_stmt_execute($stmt);
$siswa = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
$filename = basename($siswa['foto'] ?? '');
$path = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $filename;
if (!$siswa || $filename === '' || !is_file($path)) {
    http_response_code(404);
    exit;
}

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
if (!in_array($mime, ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], true)) {
    http_response_code(415);
    exit;
}

session_write_close();
header("Content-Type: $mime");
header("Content-Length: " . filesize($path));
header("X-Content-Type-Options: nosniff");
header("Cache-Control: private, no-store");
readfile($path);
