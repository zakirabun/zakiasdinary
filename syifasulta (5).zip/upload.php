<?php
include "cek_login.php";
include "koneksi.php";

// Ekstensi yang boleh => [tipe, daftar MIME yang diterima]
$boleh = [
    'jpg'  => ['foto',  ['image/jpeg']],
    'jpeg' => ['foto',  ['image/jpeg']],
    'png'  => ['foto',  ['image/png']],
    'gif'  => ['foto',  ['image/gif']],
    'webp' => ['foto',  ['image/webp']],
    'mp4'  => ['video', ['video/mp4', 'video/x-m4v']],
    'webm' => ['video', ['video/webm']],
    'mov'  => ['video', ['video/quicktime']],
    'mp3'  => ['musik', ['audio/mpeg', 'audio/mp3']],
    'm4a'  => ['musik', ['audio/mp4', 'audio/x-m4a', 'video/mp4']],
    'ogg'  => ['musik', ['audio/ogg', 'application/ogg']],
    'wav'  => ['musik', ['audio/wav', 'audio/x-wav', 'audio/vnd.wave']],
];
$batasAplikasiMedia = 50 * 1024 * 1024;
$batasAplikasiVideo = 100 * 1024 * 1024;
$keByte = static function ($nilai) {
    $nilai = trim((string) $nilai);
    if ($nilai === '') return 0;
    $unit = strtolower(substr($nilai, -1));
    $angka = (float) $nilai;
    if ($unit === 'g') return (int) ($angka * 1024 * 1024 * 1024);
    if ($unit === 'm') return (int) ($angka * 1024 * 1024);
    if ($unit === 'k') return (int) ($angka * 1024);
    return (int) $angka;
};
$batasUpload = $keByte(ini_get('upload_max_filesize'));
$batasPost = $keByte(ini_get('post_max_size'));
$batasPostAman = $batasPost > 0 ? max(1, $batasPost - 1024 * 1024) : PHP_INT_MAX;
$maksMedia = min($batasAplikasiMedia, $batasUpload > 0 ? $batasUpload : $batasAplikasiMedia, $batasPostAman);
$maksVideo = min($batasAplikasiVideo, $batasUpload > 0 ? $batasUpload : $batasAplikasiVideo, $batasPostAman);
$maksMediaTampil = max(1, (int) floor($maksMedia / (1024 * 1024)));
$maksVideoTampil = max(1, (int) floor($maksVideo / (1024 * 1024)));
$role = $_SESSION['role'];

// Room yang boleh dipakai: admin/guru semua ekskul, siswa hanya ekskul yang diikuti (cocok lewat NIS)
if ($role === 'siswa') {
    $stmt = mysqli_prepare($conn, "SELECT DISTINCT e.id, e.nama FROM ekskul e JOIN pendaftar p ON p.ekskul_id = e.id JOIN siswa s ON s.nis = p.nis WHERE s.username = ? AND s.nis <> '' ORDER BY e.nama");
    mysqli_stmt_bind_param($stmt, "s", $_SESSION['user']);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
} else {
    $res = mysqli_query($conn, "SELECT id, nama FROM ekskul ORDER BY nama");
}
$ruang = mysqli_fetch_all($res, MYSQLI_ASSOC);
$id_ruang = array_map('intval', array_column($ruang, 'id'));
$pilih = (int) ($_GET['ekskul'] ?? 0);

$pesan = "";
$sukses = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ukuranPermintaan = $keByte($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($batasPost > 0 && $ukuranPermintaan > $batasPost && empty($_POST) && empty($_FILES)) {
        $pesan = "Upload melebihi batas total permintaan server. Video maksimal sekitar $maksVideoTampil MB; media lain maksimal sekitar $maksMediaTampil MB.";
    }

    $judul = trim($_POST['judul'] ?? '');
    $ekskul_id = (int) ($_POST['ekskul_id'] ?? 0);
    $pilih = $ekskul_id;
    $f = $_FILES['berkas'] ?? null;
    $extUpload = $f ? strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) : '';
    $batasFile = in_array($extUpload, ['mp4', 'webm', 'mov'], true) ? $maksVideo : $maksMedia;
    $batasFileTampil = in_array($extUpload, ['mp4', 'webm', 'mov'], true) ? $maksVideoTampil : $maksMediaTampil;

    if ($pesan === '') {
        if (!$f || $f['error'] === UPLOAD_ERR_NO_FILE) {
            $pesan = "Pilih file dulu.";
        } elseif ($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE) {
            $pesan = "File terlalu besar untuk batas server. Batas video sekitar $maksVideoTampil MB dan media lain sekitar $maksMediaTampil MB.";
        } elseif ($f['error'] !== UPLOAD_ERR_OK) {
            $pesan = "Upload gagal (kode " . $f['error'] . ").";
        } elseif ($f['size'] > $batasFile) {
            $pesan = "File melewati batas aman server, yaitu sekitar $batasFileTampil MB.";
        } elseif ($judul === "") {
            $pesan = "Judul wajib diisi.";
        } elseif (($role === 'siswa' || $ekskul_id > 0) && !in_array($ekskul_id, $id_ruang, true)) {
            $pesan = "Pilih room ekskul yang kamu ikuti.";
        } else {
            $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($f['tmp_name']);

            if (!isset($boleh[$ext]) || !in_array($mime, $boleh[$ext][1], true)) {
                $pesan = "Format tidak didukung. Pakai: jpg, png, gif, webp, mp4, webm, mov, mp3, m4a, ogg, wav.";
            } else {
                $tipe = $boleh[$ext][0];
                if ($role === 'siswa' && !in_array($tipe, ['foto', 'video'], true)) {
                    $pesan = "Siswa dapat mengunggah foto atau video ke room ekskul yang diikuti.";
                }
            }
            if (!$pesan) {
                $nama_file = bin2hex(random_bytes(12)) . "." . $ext;

                if (!move_uploaded_file($f['tmp_name'], __DIR__ . "/uploads/" . $nama_file)) {
                    $pesan = "Gagal menyimpan file. Pastikan folder uploads bisa ditulis.";
                } else {
                    $eid = $ekskul_id > 0 ? $ekskul_id : null;
                    $stmt = mysqli_prepare($conn, "INSERT INTO media (judul, tipe, file, ekskul_id, pengunggah, peran) VALUES (?, ?, ?, ?, ?, ?)");
                    mysqli_stmt_bind_param($stmt, "sssiss", $judul, $tipe, $nama_file, $eid, $_SESSION['user'], $role);
                    mysqli_stmt_execute($stmt);
                    if ($eid) {
                        header("Location: room.php?id=$eid&ok=up");
                        exit;
                    }
                    $pesan = ucfirst($tipe) . " berhasil diunggah.";
                    $sukses = true;
                }
            }
        }
    }
}
$kembali = $role === 'siswa' ? 'profil.php' : 'admin.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Upload Media — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Upload ke Room Ekskul</h1>
    <p class="sub"><?= $role === 'siswa' ? 'Anggota dapat mengunggah foto dan video ke ekskul yang diikuti (jpg, png, gif, webp, mp4, webm, mov).' : 'Foto dan video: jpg, png, gif, webp, mp4, webm, mov. Musik maksimal 4 menit: mp3, m4a, ogg, wav.' ?> Video maksimal sekitar <?= $maksVideoTampil ?> MB dan media lain maksimal sekitar <?= $maksMediaTampil ?> MB sesuai batas server.</p>

    <?php if ($pesan) { ?><div class="alert <?= $sukses ? 'ok' : 'err' ?>"><?= htmlspecialchars($pesan) ?></div><?php } ?>

    <?php if ($role === 'siswa' && !$ruang) { ?>
        <div class="alert err">Kamu belum terdaftar di ekskul mana pun (atau NIS di profilmu belum diisi), jadi belum punya room untuk upload.</div>
        <a href="daftar.php" class="btn">Daftar Ekskul</a>
        <a href="<?= $kembali ?>" class="btn abu">Kembali</a>
    <?php } else { ?>
    <form method="post" enctype="multipart/form-data">
        <label>Room ekskul</label>
        <select name="ekskul_id" <?= $role === 'siswa' ? 'required' : '' ?>>
            <?php if ($role !== 'siswa') { ?><option value="0">-- Umum (tanpa room) --</option><?php } ?>
            <?php foreach ($ruang as $r) { ?>
                <option value="<?= $r['id'] ?>" <?= $pilih == $r['id'] ? 'selected' : '' ?>><?= htmlspecialchars($r['nama']) ?></option>
            <?php } ?>
        </select>

        <label>Judul</label>
        <input type="text" name="judul" maxlength="150" required>

        <label for="media-file">File</label>
        <input id="media-file" type="file" name="berkas" accept="<?= $role === 'siswa' ? 'image/jpeg,image/png,image/gif,image/webp,video/mp4,video/webm,video/quicktime' : 'image/jpeg,image/png,image/gif,image/webp,video/mp4,video/webm,video/quicktime,audio/mpeg,audio/mp4,audio/ogg,audio/wav' ?>" required>
        <?php if ($role !== 'siswa') { ?><p class="upload-hint">Pilih file musik berdurasi maksimal 04:00. Durasi akan diperiksa sebelum diunggah.</p><?php } ?>
        <p id="media-selection-status" class="upload-file-status" aria-live="polite"></p>

        <br><br>
        <button type="submit">Upload</button>
        <a href="galeri.php" class="btn abu">Lihat Galeri</a>
        <a href="<?= $kembali ?>" class="btn abu">Kembali</a>
    </form>
    <?php } ?>
</div>
<?php if ($role !== 'siswa' && $ruang) { ?><script src="upload.js" defer></script><?php } ?>
</body>
</html>
