<?php
include "cek_login.php";
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) $_POST['id'];
    $stmt = mysqli_prepare($conn, "SELECT file, pengunggah, peran FROM media WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $m = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    // Admin boleh hapus semua; guru hanya miliknya sendiri
    $boleh = $m && ($_SESSION['role'] === 'admin' || ($m['pengunggah'] === $_SESSION['user'] && $m['peran'] === $_SESSION['role']));
    if ($boleh) {
        $file = __DIR__ . "/uploads/" . basename($m['file']);
        if (is_file($file)) { unlink($file); }
        $stmt = mysqli_prepare($conn, "DELETE FROM media WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
    }
}
$room = (int) ($_POST['room'] ?? 0);
header("Location: " . ($room > 0 ? "room.php?id=$room&ok=hapus" : "galeri.php?ok=1"));
exit;
