<?php
// Lupa password admin / buat akun admin tanpa login.
// Dilindungi KODE_RESET yang diatur di koneksi.php.
include "koneksi.php";
include "fungsi.php";

$pesan = ""; $sukses = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode     = $_POST['kode'];
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (KODE_RESET === '' || !hash_equals(KODE_RESET, $kode)) {
        $pesan = "Kode reset salah.";
    } elseif (strlen($username) < 3 || strlen($username) > 50) {
        $pesan = "Username 3-50 karakter.";
    } elseif (strlen($password) < 6) {
        $pesan = "Password minimal 6 karakter.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "SELECT id FROM admin WHERE username = ?");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $ada = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if ($ada) {
            // Admin sudah ada: ganti passwordnya
            $stmt = mysqli_prepare($conn, "UPDATE admin SET password = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "si", $hash, $ada['id']);
            mysqli_stmt_execute($stmt);
            $pesan = "Password admin \"$username\" berhasil diganti."; $sukses = true;
        } elseif (username_dipakai($conn, $username)) {
            $pesan = "Username itu dipakai oleh akun guru atau siswa. Pilih username lain.";
        } else {
            // Belum ada: buat akun admin baru
            $stmt = mysqli_prepare($conn, "INSERT INTO admin (username, password) VALUES (?, ?)");
            mysqli_stmt_bind_param($stmt, "ss", $username, $hash);
            mysqli_stmt_execute($stmt);
            $pesan = "Akun admin \"$username\" berhasil dibuat."; $sukses = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reset / Buat Admin — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container" style="max-width:440px">
    <h1>Reset / Buat Admin</h1>
    <p class="sub">Isi username admin. Kalau sudah ada, passwordnya diganti. Kalau belum ada, akun admin baru dibuat.</p>
    <?php if ($pesan) { ?><div class="alert <?= $sukses ? 'ok' : 'err' ?>"><?= htmlspecialchars($pesan) ?></div><?php } ?>
    <form method="post">
        <label>Kode reset (KODE_RESET di koneksi.php)</label>
        <input type="password" name="kode" required>

        <label>Username admin</label>
        <input type="text" name="username" value="zaki admin" required>

        <label>Password baru</label>
        <input type="password" name="password" minlength="6" required>

        <br><br>
        <button type="submit">Simpan</button>
        <a href="login.php" class="btn abu">Ke login</a>
    </form>
</div>
</body>
</html>
