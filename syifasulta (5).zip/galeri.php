<?php
session_start();
include "koneksi.php";

$tipe = $_GET['tipe'] ?? '';
$valid = ['foto', 'video', 'musik'];

if (in_array($tipe, $valid, true)) {
    $stmt = mysqli_prepare($conn, "SELECT m.*, NULL AS ekskul FROM media m WHERE m.ekskul_id IS NULL AND m.tipe = ? ORDER BY m.tanggal DESC");
    mysqli_stmt_bind_param($stmt, "s", $tipe);
    mysqli_stmt_execute($stmt);
    $hasil = mysqli_stmt_get_result($stmt);
} else {
    $tipe = '';
    $hasil = mysqli_query($conn, "SELECT m.*, NULL AS ekskul FROM media m WHERE m.ekskul_id IS NULL ORDER BY m.tanggal DESC");
}

$login = isset($_SESSION['role']);
$kembali = !$login ? 'index.php' : ($_SESSION['role'] === 'siswa' ? 'profil.php' : 'admin.php');
$pesan = isset($_GET['ok']) ? "Media berhasil dihapus." : "";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Galeri — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="nav">
        <a href="index.php" class="brand-mark"><span class="brand-symbol">C</span><span>Clubify</span></a>
        <span class="nav-spacer"></span>
        <?php if ($login) { ?><a href="upload.php" class="btn edit">+ Upload media umum</a><?php } ?>
        <a href="<?= $kembali ?>" class="btn abu">Kembali</a>
    </div>
    <section class="gallery-hero public-gallery-hero">
        <div class="gallery-hero-copy">
            <span class="eyebrow"><span class="eyebrow-dot"></span> CERITA BERSAMA CLUBIFY</span>
            <h1>Galeri <span class="text-gradient">umum</span></h1>
            <p class="gallery-description">Jelajahi media yang dibagikan secara umum. Cerita dalam galeri ekskul tetap privat dan hanya bisa dilihat anggota.</p>
        </div>
        <div class="gallery-summary" aria-hidden="true"><strong>✦</strong><span>RUANG BERBAGI</span><div><span>foto · video · audio</span></div></div>
    </section>
    <div class="nav">
        <a href="galeri.php" class="btn <?= $tipe === '' ? '' : 'abu' ?>">Semua</a>
        <a href="galeri.php?tipe=foto" class="btn <?= $tipe === 'foto' ? '' : 'abu' ?>">Foto</a>
        <a href="galeri.php?tipe=video" class="btn <?= $tipe === 'video' ? '' : 'abu' ?>">Video</a>
        <a href="galeri.php?tipe=musik" class="btn <?= $tipe === 'musik' ? '' : 'abu' ?>">Musik</a>
    </div>

    <?php if ($pesan) { ?><div class="alert ok"><?= $pesan ?></div><?php } ?>

    <div class="grid">
        <?php $ada = false; while ($m = mysqli_fetch_assoc($hasil)) { $ada = true;
            $src = "media_file.php?id=" . (int) $m['id']; ?>
        <article class="card gallery-card">
            <?php if ($m['tipe'] === 'foto') { ?>
                <a class="gallery-image-link" href="<?= $src ?>" target="_blank" rel="noopener" data-lightbox-title="<?= htmlspecialchars($m['judul'], ENT_QUOTES, 'UTF-8') ?>"><img class="gallery-image" src="<?= $src ?>" alt="<?= htmlspecialchars($m['judul']) ?>" loading="lazy"><span class="image-zoom" aria-hidden="true">↗ Perbesar</span></a>
            <?php } elseif ($m['tipe'] === 'video') { ?>
                <div class="video-stage"><video class="media gallery-video" src="<?= $src ?>" controls playsinline preload="metadata"></video><span class="video-badge"><span aria-hidden="true">▶</span> VIDEO KEGIATAN</span><p class="media-error" hidden>Video ini tidak bisa diputar. Periksa format dan file videonya.</p></div>
            <?php } else { ?>
                <div class="audio-player" data-audio-player>
                    <div class="audio-art" aria-hidden="true"><span>♫</span><div class="audio-wave" aria-hidden="true"></div></div>
                    <audio class="gallery-audio" src="<?= $src ?>" controls preload="metadata"></audio>
                    <div class="audio-controls" hidden>
                        <button class="audio-toggle" type="button" aria-label="Putar audio"><span class="audio-toggle-icon" aria-hidden="true">▶</span><span class="audio-toggle-label">Putar</span></button>
                        <div class="audio-progress"><span class="audio-current">0:00</span><input type="range" min="0" max="1000" value="0" aria-label="Posisi audio"><span class="audio-duration">--:--</span></div>
                        <p class="media-error" hidden>Audio ini tidak bisa diputar. Periksa format dan file audionya.</p>
                    </div>
                </div>
            <?php } ?>
            <div class="gallery-card-info"><div><span class="media-type"><?= ucfirst($m['tipe'] === 'musik' ? 'audio' : $m['tipe']) ?></span><h3><?= htmlspecialchars($m['judul']) ?></h3><p class="meta">oleh <?= htmlspecialchars($m['pengunggah']) ?> &middot; <?= date('d M Y', strtotime($m['tanggal'])) ?></p></div>
            <?php if ($login && ($_SESSION['role'] === 'admin' || $_SESSION['user'] === $m['pengunggah'] && $_SESSION['role'] === $m['peran'])) { ?>
            <form method="post" action="media_hapus.php" class="inline" onsubmit="return confirm('Hapus media ini?')">
                <input type="hidden" name="id" value="<?= $m['id'] ?>">
                <button type="submit" class="btn hapus" aria-label="Hapus <?= htmlspecialchars($m['judul']) ?>">Hapus</button>
            </form>
            <?php } ?>
            </div>
        </article>
        <?php } ?>
        <?php if (!$ada) { ?><div class="gallery-empty"><span aria-hidden="true">✧</span><h2>Galeri umum masih kosong</h2><p>Media yang diunggah tanpa memilih room ekskul akan tampil di sini.</p></div><?php } ?>
    </div>
    <dialog class="photo-lightbox" id="photo-lightbox" aria-label="Foto galeri">
        <form method="dialog"><button class="lightbox-close" aria-label="Tutup foto">×</button></form>
        <img src="" alt="">
        <p></p>
    </dialog>
</div>
<script src="gallery.js" defer></script>
</body>
</html>
