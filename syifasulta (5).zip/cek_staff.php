<?php
// Hanya admin dan guru (siswa dialihkan ke profilnya)
include "cek_login.php";
if ($_SESSION['role'] === 'siswa') {
    header("Location: profil.php");
    exit;
}
