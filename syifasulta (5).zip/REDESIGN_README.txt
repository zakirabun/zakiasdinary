REDESIGN CLUBIFY

Pembaruan antarmuka:
- Halaman utama memiliki hero, ringkasan jumlah ekskul/peserta/slot, dan kartu ekskul dengan informasi pembina, jadwal, status kuota, serta progres kapasitas.
- Setiap kartu ekskul menampilkan sampul ilustratif tanpa membuka foto privat; galeri kegiatan dibatasi untuk anggota ekskul, admin, dan guru.
- Galeri foto memiliki tampilan perbesar; video menggunakan pemutar responsif dengan pesan jika file tidak dapat diputar.
- Musik menggunakan pemutar khusus dengan tombol putar/jeda, posisi dan durasi, serta visual gelombang; memutar trek baru menjeda trek sebelumnya.
- Unggah musik memeriksa durasi file dan membatasi pilihan hingga empat menit.
- Anggota ekskul dapat mengunggah video MP4, WebM, dan MOV hingga 100 MB ke ekskul yang mereka ikuti; media lain dibatasi 50 MB. Batas aktual mengikuti konfigurasi PHP.
- Halaman galeri memiliki ringkasan foto/video/audio, filter per jenis media, serta tampilan kartu dan kondisi galeri kosong.
- Akses galeri diperiksa di halaman dan endpoint file; berkas dalam folder uploads tidak dapat dibuka langsung.
- Pencarian ekskul berdasarkan nama, pembina, atau jadwal; filter untuk ekskul yang masih tersedia; dan pesan saat hasil tidak ditemukan.
- Dashboard admin/guru menampilkan ringkasan ekskul, peserta, dan kursi yang masih tersedia.
- Gaya visual krem hangat dan klasik-modern diterapkan pada navigasi, kartu, form, tabel, galeri, dan layar ponsel.
- Tata letak menyesuaikan desktop, tablet, dan ponsel dengan navigasi, kartu, filter, form, serta tabel yang tetap nyaman digunakan.
- Nama Clubify digunakan secara konsisten sebagai identitas aplikasi dan judul tab halaman.

Alur pendaftaran, room, galeri, unggah media, dan manajemen akun tetap memakai fitur yang sudah ada. Jalankan proyek melalui XAMPP/Laragon dan impor database.sql.
