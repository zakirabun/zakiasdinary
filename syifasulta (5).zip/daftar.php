<?php
include "koneksi.php";
session_start();

// Siswa yang sudah login: data diisi otomatis
$pre = ['nis' => '', 'nama' => '', 'kelas' => ''];
if (($_SESSION['role'] ?? '') === 'siswa') {
    $q = mysqli_prepare($conn, "SELECT nis, nama, kelas FROM siswa WHERE username = ?");
    mysqli_stmt_bind_param($q, "s", $_SESSION['user']);
    mysqli_stmt_execute($q);
    $r = mysqli_fetch_assoc(mysqli_stmt_get_result($q));
    if ($r) $pre = $r;
}

$pesan = "";
$sukses = false;
$pilih = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nis       = trim($_POST['nis']);
    $nama      = trim($_POST['nama']);
    $kelas     = trim($_POST['kelas']);
    $ekskul_id = (int) $_POST['ekskul_id'];
    $pilih     = $ekskul_id;

    // 1. Ambil data ekskul + jumlah pendaftar saat ini
    $stmt = mysqli_prepare($conn, "SELECT kuota, (SELECT COUNT(*) FROM pendaftar WHERE ekskul_id = ?) AS terisi FROM ekskul WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $ekskul_id, $ekskul_id);
    mysqli_stmt_execute($stmt);
    $e = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$e) {
        $pesan = "Ekskul tidak ditemukan.";
    } elseif ($e['terisi'] >= $e['kuota']) {
        $pesan = "Maaf, kuota ekskul ini sudah penuh.";
    } else {
        // 2. Cek apakah NIS sudah terdaftar di ekskul yang sama
        $stmt = mysqli_prepare($conn, "SELECT id FROM pendaftar WHERE nis = ? AND ekskul_id = ?");
        mysqli_stmt_bind_param($stmt, "si", $nis, $ekskul_id);
        mysqli_stmt_execute($stmt);
        if (mysqli_stmt_get_result($stmt)->num_rows > 0) {
            $pesan = "NIS ini sudah terdaftar di ekskul tersebut.";
        } else {
            // 3. Simpan pendaftaran
            $stmt = mysqli_prepare($conn, "INSERT INTO pendaftar (nis, nama, kelas, ekskul_id) VALUES (?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "sssi", $nis, $nama, $kelas, $ekskul_id);
            mysqli_stmt_execute($stmt);
            $pesan = "Pendaftaran berhasil! Sampai jumpa di ekskul.";
            $sukses = true;
        }
    }
}

$daftar = mysqli_query($conn, "SELECT e.*, (SELECT COUNT(*) FROM pendaftar p WHERE p.ekskul_id = e.id) AS terisi FROM ekskul e ORDER BY e.nama");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Form Pendaftaran — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Form Pendaftaran Ekskul</h1>

    <?php if ($pesan) { ?>
        <div class="alert <?= $sukses ? 'ok' : 'err' ?>"><?= $pesan ?></div>
    <?php } ?>

    <form method="post">
        <label>NIS</label>
        <input type="text" name="nis" value="<?= htmlspecialchars($pre['nis']) ?>" required>

        <label>Nama Lengkap</label>
        <input type="text" name="nama" value="<?= htmlspecialchars($pre['nama']) ?>" required>

        <label>Kelas</label>
        <input type="text" name="kelas" value="<?= htmlspecialchars($pre['kelas']) ?>" placeholder="contoh: XI RPL 1" required>

        <label>Pilih Ekskul</label>
        <select name="ekskul_id" required>
            <option value="">-- Pilih --</option>
            <?php while ($e = mysqli_fetch_assoc($daftar)) {
                $penuh = $e['terisi'] >= $e['kuota']; ?>
                <option value="<?= $e['id'] ?>" <?= $pilih == $e['id'] ? 'selected' : '' ?> <?= $penuh ? 'disabled' : '' ?>>
                    <?= htmlspecialchars($e['nama']) ?> (<?= $e['terisi'] ?>/<?= $e['kuota'] ?>)<?= $penuh ? ' - Penuh' : '' ?>
                </option>
            <?php } ?>
        </select>

        <br><br>
        <button type="submit">Daftar</button>
        <a href="index.php" class="btn abu">Kembali</a>
    </form>
</div>
</body>
</html>
