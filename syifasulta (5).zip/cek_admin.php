<?php
// Hanya admin yang boleh lewat
include "cek_login.php";
if ($_SESSION['role'] !== 'admin') {
    header("Location: admin.php");
    exit;
}
