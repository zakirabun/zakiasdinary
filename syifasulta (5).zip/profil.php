<?php
include "cek_login.php";
include "koneksi.php";
include "fungsi.php";

if ($_SESSION['role'] !== 'siswa') { header("Location: admin.php"); exit; }

$stmt = mysqli_prepare($conn, "SELECT * FROM siswa WHERE username = ?");
mysqli_stmt_bind_param($stmt, "s", $_SESSION['user']);
mysqli_stmt_execute($stmt);
$me = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if (!$me) { session_destroy(); header("Location: login.php"); exit; }

$pesan = ""; $sukses = false;

// Isi NIS (untuk akun lama yang belum punya)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'nis') {
    $nis = trim($_POST['nis']);
    if (!preg_match('/^[0-9A-Za-z]{3,20}$/', $nis)) {
        $pesan = "NIS 3-20 karakter (huruf atau angka).";
    } elseif (nis_dipakai($conn, $nis, (int) $me['id'])) {
        $pesan = "NIS sudah terhubung ke akun siswa lain.";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE siswa SET nis = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "si", $nis, $me['id']);
        mysqli_stmt_execute($stmt);
        $me['nis'] = $nis;
        $pesan = "NIS disimpan."; $sukses = true;
    }

// Ganti foto profil
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipe_ok = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $f = $_FILES['foto'] ?? null;

    if (!$f || $f['error'] === UPLOAD_ERR_NO_FILE) {
        $pesan = "Pilih foto dulu.";
    } elseif ($f['error'] !== UPLOAD_ERR_OK) {
        $pesan = "Upload gagal (kode " . $f['error'] . ").";
    } elseif ($f['size'] > 5 * 1024 * 1024) {
        $pesan = "Foto profil maksimal 5 MB.";
    } else {
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
        if (!isset($tipe_ok[$mime])) {
            $pesan = "Format harus jpg, png, webp, atau gif.";
        } else {
            $nama_file = "profil_" . bin2hex(random_bytes(10)) . "." . $tipe_ok[$mime];
            if (move_uploaded_file($f['tmp_name'], __DIR__ . "/uploads/" . $nama_file)) {
                if ($me['foto'] && is_file(__DIR__ . "/uploads/" . basename($me['foto']))) {
                    unlink(__DIR__ . "/uploads/" . basename($me['foto']));
                }
                $stmt = mysqli_prepare($conn, "UPDATE siswa SET foto = ? WHERE id = ?");
                mysqli_stmt_bind_param($stmt, "si", $nama_file, $me['id']);
                mysqli_stmt_execute($stmt);
                $me['foto'] = $nama_file;
                $pesan = "Foto profil diperbarui."; $sukses = true;
            } else {
                $pesan = "Gagal menyimpan foto. Pastikan folder uploads bisa ditulis.";
            }
        }
    }
}

$stmt = mysqli_prepare($conn, "SELECT DISTINCT e.id, e.nama FROM ekskul e JOIN pendaftar p ON p.ekskul_id = e.id WHERE p.nis = ? AND p.nis <> '' ORDER BY e.nama");
mysqli_stmt_bind_param($stmt, "s", $me['nis']);
mysqli_stmt_execute($stmt);
$rooms = mysqli_stmt_get_result($stmt);

$stmt = mysqli_prepare($conn, "SELECT * FROM media WHERE pengunggah = ? AND peran = 'siswa' ORDER BY tanggal DESC");
mysqli_stmt_bind_param($stmt, "s", $me['username']);
mysqli_stmt_execute($stmt);
$post = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profil Saya — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="profil-head">
        <?php if ($me['foto']) { ?>
            <img class="avatar" src="foto_profil.php" alt="Foto profil">
        <?php } else { ?>
            <div class="avatar"><?= htmlspecialchars(mb_strtoupper(mb_substr($me['nama'], 0, 1))) ?></div>
        <?php } ?>
        <div>
            <h1><?= htmlspecialchars($me['nama']) ?></h1>
            <p class="sub">@<?= htmlspecialchars($me['username']) ?> &middot; <?= htmlspecialchars($me['kelas']) ?></p>
        </div>
    </div>

    <div class="nav">
        <a href="upload.php" class="btn">+ Posting Foto</a>
        <a href="daftar.php" class="btn edit">Daftar Ekskul</a>
        <a href="galeri.php" class="btn abu">Galeri</a>
        <a href="logout.php" class="btn hapus">Logout</a>
    </div>

    <?php if ($pesan) { ?><div class="alert <?= $sukses ? 'ok' : 'err' ?>"><?= htmlspecialchars($pesan) ?></div><?php } ?>

    <?php if ($me['nis'] === '') { ?>
    <form method="post" style="margin-bottom:16px">
        <input type="hidden" name="aksi" value="nis">
        <label>Isi NIS kamu (supaya terhubung ke room ekskul)</label>
        <input type="text" name="nis" required>
        <button type="submit">Simpan NIS</button>
    </form>
    <?php } else { ?>
    <h2>Room ekskul saya</h2>
    <div class="nav">
        <?php $adaroom = false; while ($r = mysqli_fetch_assoc($rooms)) { $adaroom = true; ?>
            <a class="btn" href="room.php?id=<?= $r['id'] ?>"><?= htmlspecialchars($r['nama']) ?></a>
        <?php } ?>
        <?php if (!$adaroom) { ?><span class="sub">Belum terdaftar di ekskul mana pun. <a href="daftar.php">Daftar sekarang</a>.</span><?php } ?>
    </div>
    <?php } ?>

    <form method="post" enctype="multipart/form-data">
        <label>Ganti foto profil</label>
        <input type="file" name="foto" accept="image/*" required>
        <button type="submit">Simpan Foto</button>
    </form>

    <h2 style="margin-top:24px">Postingan saya</h2>
    <div class="grid">
        <?php $ada = false; while ($m = mysqli_fetch_assoc($post)) {
            if ($m['ekskul_id'] && !boleh_akses_room($conn, (int) $m['ekskul_id'])) continue;
            $ada = true;
            $postSrc = "media_file.php?id=" . (int) $m['id']; ?>
        <div class="card">
            <a href="<?= $postSrc ?>" target="_blank" rel="noopener"><img class="media" src="<?= $postSrc ?>" alt="<?= htmlspecialchars($m['judul']) ?>" loading="lazy"></a>
            <h3><?= htmlspecialchars($m['judul']) ?></h3>
            <p class="meta"><?= date('d M Y', strtotime($m['tanggal'])) ?></p>
            <form method="post" action="media_hapus.php" class="inline" onsubmit="return confirm('Hapus postingan ini?')">
                <input type="hidden" name="id" value="<?= $m['id'] ?>">
                <button type="submit" class="btn hapus">Hapus</button>
            </form>
        </div>
        <?php } ?>
        <?php if (!$ada) { ?><p class="sub">Belum ada postingan.</p><?php } ?>
    </div>
</div>
</body>
</html>
