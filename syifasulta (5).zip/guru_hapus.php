<?php
include "cek_admin.php";
include "koneksi.php";

// Hapus lewat POST saja
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) $_POST['id'];
    $stmt = mysqli_prepare($conn, "DELETE FROM guru WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    header("Location: pengguna.php?ok=hapus");
    exit;
}
header("Location: pengguna.php");
exit;
