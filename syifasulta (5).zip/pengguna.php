<?php
include "cek_admin.php";
include "koneksi.php";

$daftar_admin = mysqli_query($conn, "SELECT id, username FROM admin ORDER BY username");
$daftar_guru  = mysqli_query($conn, "SELECT id, nama, username, dibuat FROM guru ORDER BY nama");

$daftar_siswa = mysqli_query($conn, "SELECT id, nama, username, kelas, dibuat FROM siswa ORDER BY nama");

$pesan = "";
if (isset($_GET['ok'])) {
    $teks = ['tambah' => 'Akun guru berhasil dibuat.', 'edit' => 'Akun guru berhasil diperbarui.', 'hapus' => 'Akun guru berhasil dihapus.', 'siswa' => 'Akun siswa berhasil dihapus.', 'admin_tambah' => 'Akun admin berhasil dibuat.', 'admin_edit' => 'Password admin berhasil diganti.', 'admin_hapus' => 'Akun admin berhasil dihapus.', 'admin_gagal' => 'Tidak bisa menghapus: akun sendiri atau admin terakhir.'];
    $pesan = $teks[$_GET['ok']] ?? "";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar User — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Daftar User</h1>
    <p class="sub">Akun guru hanya bisa dibuat oleh admin. Siswa mendaftar sendiri lewat halaman Buat Akun.</p>
    <div class="nav">
        <a href="guru_form.php" class="btn">+ Tambah Guru</a>
        <a href="admin_form.php" class="btn edit">+ Tambah Admin</a>
        <a href="admin.php" class="btn abu">Dashboard</a>
        <a href="logout.php" class="btn hapus">Logout</a>
    </div>

    <?php if ($pesan) { ?><div class="alert <?= $_GET['ok'] === 'admin_gagal' ? 'err' : 'ok' ?>"><?= $pesan ?></div><?php } ?>

    <h2>Admin</h2>
    <table>
        <tr><th>No</th><th>Username</th><th>Aksi</th></tr>
        <?php $no = 1; while ($a = mysqli_fetch_assoc($daftar_admin)) { ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($a['username']) ?><?= $a['username'] === $_SESSION['user'] ? ' (kamu)' : '' ?></td>
            <td>
                <a class="btn edit" href="admin_form.php?id=<?= $a['id'] ?>">Ganti Password</a>
                <?php if ($a['username'] !== $_SESSION['user']) { ?>
                <form method="post" action="admin_hapus.php" class="inline" onsubmit="return confirm('Hapus akun admin ini?')">
                    <input type="hidden" name="id" value="<?= $a['id'] ?>">
                    <button type="submit" class="btn hapus">Hapus</button>
                </form>
                <?php } ?>
            </td>
        </tr>
        <?php } ?>
    </table>

    <h2 style="margin-top:24px">Guru</h2>
    <table>
        <tr><th>No</th><th>Nama</th><th>Username</th><th>Dibuat</th><th>Aksi</th></tr>
        <?php $no = 1; $ada = false; while ($g = mysqli_fetch_assoc($daftar_guru)) { $ada = true; ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($g['nama']) ?></td>
            <td><?= htmlspecialchars($g['username']) ?></td>
            <td><?= $g['dibuat'] ?></td>
            <td>
                <a class="btn edit" href="guru_form.php?id=<?= $g['id'] ?>">Edit</a>
                <form method="post" action="guru_hapus.php" class="inline" onsubmit="return confirm('Hapus akun guru ini?')">
                    <input type="hidden" name="id" value="<?= $g['id'] ?>">
                    <button type="submit" class="btn hapus">Hapus</button>
                </form>
            </td>
        </tr>
        <?php } ?>
        <?php if (!$ada) { ?><tr><td colspan="5">Belum ada akun guru. Klik "+ Tambah Guru".</td></tr><?php } ?>
    </table>

    <h2 style="margin-top:24px">Siswa</h2>
    <table>
        <tr><th>No</th><th>Nama</th><th>Username</th><th>Kelas</th><th>Dibuat</th><th>Aksi</th></tr>
        <?php $no = 1; $ada = false; while ($w = mysqli_fetch_assoc($daftar_siswa)) { $ada = true; ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($w['nama']) ?></td>
            <td><?= htmlspecialchars($w['username']) ?></td>
            <td><?= htmlspecialchars($w['kelas']) ?></td>
            <td><?= $w['dibuat'] ?></td>
            <td>
                <form method="post" action="siswa_hapus.php" class="inline" onsubmit="return confirm('Hapus akun siswa ini beserta foto yang diunggahnya?')">
                    <input type="hidden" name="id" value="<?= $w['id'] ?>">
                    <button type="submit" class="btn hapus">Hapus</button>
                </form>
            </td>
        </tr>
        <?php } ?>
        <?php if (!$ada) { ?><tr><td colspan="6">Belum ada siswa yang mendaftar.</td></tr><?php } ?>
    </table>
</div>
</body>
</html>
