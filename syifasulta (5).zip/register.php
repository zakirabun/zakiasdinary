<?php
session_start();
include "koneksi.php";
include "fungsi.php";

$error = "";
$d = ['nama' => '', 'nis' => '', 'username' => '', 'kelas' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $d['nama']     = trim($_POST['nama']);
    $d['nis']      = trim($_POST['nis']);
    $d['username'] = trim($_POST['username']);
    $d['kelas']    = trim($_POST['kelas']);
    $password      = $_POST['password'];
    $ulang         = $_POST['ulang'];

    if ($d['nama'] === "" || $d['kelas'] === "") {
        $error = "Nama dan kelas wajib diisi.";
    } elseif (!preg_match('/^[0-9A-Za-z]{3,20}$/', $d['nis'])) {
        $error = "NIS 3-20 karakter (huruf atau angka).";
    } elseif (!preg_match('/^[A-Za-z0-9_.]{3,50}$/', $d['username'])) {
        $error = "Username 3-50 karakter: huruf, angka, titik, atau garis bawah.";
    } elseif (nis_dipakai($conn, $d['nis'])) {
        $error = "NIS sudah terhubung ke akun siswa lain.";
    } elseif (strlen($password) < 6) {
        $error = "Password minimal 6 karakter.";
    } elseif ($password !== $ulang) {
        $error = "Konfirmasi password tidak sama.";
    } elseif (username_dipakai($conn, $d['username'])) {
        $error = "Username sudah dipakai.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO siswa (nama, nis, username, password, kelas) VALUES (?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sssss", $d['nama'], $d['nis'], $d['username'], $hash, $d['kelas']);
        mysqli_stmt_execute($stmt);

        // Langsung masuk setelah daftar
        session_regenerate_id(true);
        $_SESSION['role'] = 'siswa';
        $_SESSION['user'] = $d['username'];
        header("Location: profil.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Buat Akun — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container" style="max-width:440px">
    <h1>Buat Akun Siswa</h1>
    <p class="sub">Punya akun? <a href="login.php">Login di sini</a>.</p>
    <?php if ($error) { ?><div class="alert err"><?= htmlspecialchars($error) ?></div><?php } ?>
    <form method="post">
        <label>Nama Lengkap</label>
        <input type="text" name="nama" value="<?= htmlspecialchars($d['nama']) ?>" required>

        <label>NIS</label>
        <input type="text" name="nis" value="<?= htmlspecialchars($d['nis']) ?>" required>

        <label>Kelas</label>
        <input type="text" name="kelas" value="<?= htmlspecialchars($d['kelas']) ?>" placeholder="contoh: XI RPL 1" required>

        <label>Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($d['username']) ?>" required>

        <label>Password</label>
        <input type="password" name="password" minlength="6" required>

        <label>Ulangi Password</label>
        <input type="password" name="ulang" minlength="6" required>

        <br><br>
        <button type="submit">Buat Akun</button>
        <a href="index.php" class="btn abu">Kembali</a>
    </form>
</div>
</body>
</html>
