<?php
include "cek_admin.php";
include "koneksi.php";

$hasil = "admin_gagal";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) $_POST['id'];
    $stmt = mysqli_prepare($conn, "SELECT username FROM admin WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $a = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    $jumlah = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM admin"))['n'];

    // Tidak boleh hapus akun sendiri atau admin terakhir
    if ($a && $a['username'] !== $_SESSION['user'] && $jumlah > 1) {
        $stmt = mysqli_prepare($conn, "DELETE FROM admin WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $hasil = "admin_hapus";
    }
}
header("Location: pengguna.php?ok=$hasil");
exit;
