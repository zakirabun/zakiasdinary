(() => {
    const form = document.querySelector('form[enctype="multipart/form-data"]');
    const input = document.getElementById('media-file');
    const status = document.getElementById('media-selection-status');
    if (!form || !input || !status) return;

    const maxDuration = 4 * 60;
    const audioExtensions = new Set(['mp3', 'm4a', 'ogg', 'wav']);
    let selectedFile = null;
    let validatedFile = null;
    let duration = null;
    let validationRequest = 0;

    const formatDuration = (seconds) => {
        const totalSeconds = Math.ceil(seconds);
        const minutes = Math.floor(totalSeconds / 60);
        return `${String(minutes).padStart(2, '0')}:${String(totalSeconds % 60).padStart(2, '0')}`;
    };

    const isAudio = (file) => audioExtensions.has(file.name.split('.').pop().toLowerCase());

    const inspectAudio = (file) => new Promise((resolve, reject) => {
        const audio = new Audio();
        const url = URL.createObjectURL(file);
        const cleanup = () => {
            audio.removeAttribute('src');
            audio.load();
            URL.revokeObjectURL(url);
        };
        const timeout = window.setTimeout(() => {
            cleanup();
            reject(new Error('Waktu pemeriksaan audio habis. Coba pilih file lain.'));
        }, 15000);

        audio.preload = 'metadata';
        audio.onloadedmetadata = () => {
            window.clearTimeout(timeout);
            const length = audio.duration;
            cleanup();
            if (!Number.isFinite(length) || length <= 0) {
                reject(new Error('Durasi file musik tidak dapat dibaca. Coba gunakan MP3, M4A, OGG, atau WAV.'));
                return;
            }
            resolve(length);
        };
        audio.onerror = () => {
            window.clearTimeout(timeout);
            cleanup();
            reject(new Error('File musik tidak dapat dibaca. Pastikan formatnya MP3, M4A, OGG, atau WAV.'));
        };
        audio.src = url;
    });

    input.addEventListener('change', async () => {
        selectedFile = input.files[0] ?? null;
        validatedFile = null;
        duration = null;
        const request = ++validationRequest;
        status.classList.remove('is-error', 'is-success');

        if (!selectedFile) {
            status.textContent = '';
            return;
        }

        if (!isAudio(selectedFile)) {
            status.textContent = `${selectedFile.name} dipilih.`;
            status.classList.add('is-success');
            return;
        }

        status.textContent = 'Memeriksa durasi musik...';
        try {
            const length = await inspectAudio(selectedFile);
            if (request !== validationRequest || selectedFile !== input.files[0]) return;

            if (length > maxDuration) {
                status.textContent = `Durasi ${formatDuration(length)} melebihi batas 04:00. Pilih musik yang lebih pendek.`;
                status.classList.add('is-error');
                return;
            }

            duration = length;
            validatedFile = selectedFile;
            status.textContent = `Durasi ${formatDuration(length)} — siap diunggah.`;
            status.classList.add('is-success');
        } catch (error) {
            if (request !== validationRequest || selectedFile !== input.files[0]) return;
            status.textContent = error.message;
            status.classList.add('is-error');
        }
    });

    form.addEventListener('submit', async (event) => {
        const file = input.files[0];
        if (!file || !isAudio(file) || (validatedFile === file && duration <= maxDuration)) return;

        event.preventDefault();
        status.classList.remove('is-error', 'is-success');
        status.textContent = 'Memeriksa durasi musik sebelum upload...';

        try {
            const length = await inspectAudio(file);
            if (input.files[0] !== file) {
                status.textContent = 'File berubah. Periksa file yang baru dipilih.';
                status.classList.add('is-error');
                return;
            }
            if (length > maxDuration) {
                status.textContent = `Upload dibatalkan: durasi ${formatDuration(length)} melebihi batas 04:00.`;
                status.classList.add('is-error');
                return;
            }

            duration = length;
            validatedFile = file;
            status.textContent = `Durasi ${formatDuration(length)} — memulai upload...`;
            form.requestSubmit(event.submitter ?? undefined);
        } catch (error) {
            status.textContent = error.message;
            status.classList.add('is-error');
        }
    });
})();
