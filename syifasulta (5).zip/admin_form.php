<?php
include "cek_admin.php";
include "koneksi.php";
include "fungsi.php";

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$edit = $id > 0;
$username = "";
$error = "";

if ($edit) {
    $stmt = mysqli_prepare($conn, "SELECT username FROM admin WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if (!$row) { header("Location: pengguna.php"); exit; }
    $username = $row['username'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'];
    if (!$edit) $username = trim($_POST['username']);

    if (!$edit && (strlen($username) < 3 || strlen($username) > 50)) {
        $error = "Username 3-50 karakter.";
    } elseif (!$edit && username_dipakai($conn, $username)) {
        $error = "Username sudah dipakai.";
    } elseif (strlen($password) < 6) {
        $error = "Password minimal 6 karakter.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        if ($edit) {
            $stmt = mysqli_prepare($conn, "UPDATE admin SET password = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "si", $hash, $id);
            $ok = "admin_edit";
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO admin (username, password) VALUES (?, ?)");
            mysqli_stmt_bind_param($stmt, "ss", $username, $hash);
            $ok = "admin_tambah";
        }
        mysqli_stmt_execute($stmt);
        header("Location: pengguna.php?ok=$ok");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $edit ? 'Ganti Password Admin' : 'Tambah Admin' ?> — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1><?= $edit ? 'Ganti Password Admin' : 'Tambah Akun Admin' ?></h1>
    <?php if ($error) { ?><div class="alert err"><?= htmlspecialchars($error) ?></div><?php } ?>
    <form method="post">
        <input type="hidden" name="id" value="<?= $id ?>">

        <label>Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($username) ?>" <?= $edit ? 'readonly' : 'required' ?>>

        <label><?= $edit ? 'Password baru' : 'Password' ?></label>
        <input type="password" name="password" minlength="6" required>

        <br><br>
        <button type="submit">Simpan</button>
        <a href="pengguna.php" class="btn abu">Batal</a>
    </form>
</div>
</body>
</html>
