CREATE DATABASE IF NOT EXISTS db_ekskul;
USE db_ekskul;

CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS guru (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    dibuat DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS siswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    nis VARCHAR(20) NOT NULL DEFAULT '',
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    kelas VARCHAR(20) NOT NULL,
    foto VARCHAR(255) NULL,
    dibuat DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ekskul (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    pembina VARCHAR(100) NOT NULL,
    jadwal VARCHAR(100) NOT NULL,
    kuota INT NOT NULL DEFAULT 20
);

CREATE TABLE IF NOT EXISTS pendaftar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nis VARCHAR(20) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    kelas VARCHAR(20) NOT NULL,
    ekskul_id INT NOT NULL,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unik_daftar (nis, ekskul_id),
    FOREIGN KEY (ekskul_id) REFERENCES ekskul(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS media (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(150) NOT NULL,
    tipe ENUM('foto','video','musik') NOT NULL,
    file VARCHAR(255) NOT NULL,
    ekskul_id INT NULL,
    pengunggah VARCHAR(50) NOT NULL,
    peran VARCHAR(10) NOT NULL,
    tanggal DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ekskul_id) REFERENCES ekskul(id) ON DELETE SET NULL
);

INSERT INTO ekskul (nama, pembina, jadwal, kuota) VALUES
('Pramuka', 'Pak Budi', 'Jumat, 14.00', 30),
('Futsal', 'Pak Rian', 'Sabtu, 08.00', 15),
('Robotik', 'Bu Sari', 'Rabu, 14.30', 10),
('Paskibra', 'Pak Dedi', 'Selasa, 14.00', 20);
