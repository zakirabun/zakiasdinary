<?php
include "cek_admin.php";
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) $_POST['id'];
    $stmt = mysqli_prepare($conn, "SELECT username, foto FROM siswa WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $w = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($w) {
        // Hapus file postingan siswa ini
        $stmt = mysqli_prepare($conn, "SELECT file FROM media WHERE pengunggah = ? AND peran = 'siswa'");
        mysqli_stmt_bind_param($stmt, "s", $w['username']);
        mysqli_stmt_execute($stmt);
        $hasil = mysqli_stmt_get_result($stmt);
        while ($m = mysqli_fetch_assoc($hasil)) {
            $path = __DIR__ . "/uploads/" . basename($m['file']);
            if (is_file($path)) unlink($path);
        }
        $stmt = mysqli_prepare($conn, "DELETE FROM media WHERE pengunggah = ? AND peran = 'siswa'");
        mysqli_stmt_bind_param($stmt, "s", $w['username']);
        mysqli_stmt_execute($stmt);

        if ($w['foto']) {
            $path = __DIR__ . "/uploads/" . basename($w['foto']);
            if (is_file($path)) unlink($path);
        }
        $stmt = mysqli_prepare($conn, "DELETE FROM siswa WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
    }
}
header("Location: pengguna.php?ok=siswa");
exit;
