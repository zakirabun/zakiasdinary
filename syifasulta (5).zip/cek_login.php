<?php
// Wajib login (admin atau guru)
session_start();
if (!isset($_SESSION['role'])) {
    header("Location: login.php");
    exit;
}
