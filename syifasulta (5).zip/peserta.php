<?php
include "cek_staff.php";
include "koneksi.php";

$id = (int) $_GET['id'];
$e = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM ekskul WHERE id = $id"));
if (!$e) { header("Location: admin.php"); exit; }

$hasil = mysqli_query($conn, "SELECT * FROM pendaftar WHERE ekskul_id = $id ORDER BY nama");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Peserta <?= htmlspecialchars($e['nama']) ?> — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Peserta: <?= htmlspecialchars($e['nama']) ?></h1>
    <a href="admin.php" class="btn abu">Kembali</a>
    <button onclick="window.print()">Cetak</button>

    <table>
        <tr><th>No</th><th>NIS</th><th>Nama</th><th>Kelas</th><th>Tanggal Daftar</th><?php if ($_SESSION['role'] === 'admin') { ?><th>Aksi</th><?php } ?></tr>
        <?php $no = 1; while ($p = mysqli_fetch_assoc($hasil)) { ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($p['nis']) ?></td>
            <td><?= htmlspecialchars($p['nama']) ?></td>
            <td><?= htmlspecialchars($p['kelas']) ?></td>
            <td><?= $p['tanggal'] ?></td>
            <?php if ($_SESSION['role'] === 'admin') { ?>
            <td><a class="btn hapus" href="peserta_hapus.php?id=<?= $p['id'] ?>&ekskul=<?= $id ?>" onclick="return confirm('Hapus peserta ini?')">Hapus</a></td>
            <?php } ?>
        </tr>
        <?php } ?>
    </table>
</div>
</body>
</html>
