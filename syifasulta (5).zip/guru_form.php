<?php
include "cek_admin.php";
include "koneksi.php";
include "fungsi.php";

$data = ['id' => '', 'nama' => '', 'username' => ''];
$error = "";

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    $stmt = mysqli_prepare($conn, "SELECT id, nama, username FROM guru WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if (!$row) { header("Location: pengguna.php"); exit; }
    $data = $row;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id       = (int) $_POST['id'];
    $nama     = trim($_POST['nama']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $data = ['id' => $id ?: '', 'nama' => $nama, 'username' => $username];

    // Username tidak boleh sama dengan admin, guru, atau siswa lain
    $dipakai = username_dipakai($conn, $username, $id);

    if ($nama === "" || strlen($username) < 3 || strlen($username) > 50) {
        $error = "Nama wajib diisi dan username 3-50 karakter.";
    } elseif ($dipakai) {
        $error = "Username sudah dipakai.";
    } elseif ($id == 0 && strlen($password) < 6) {
        $error = "Password minimal 6 karakter.";
    } elseif ($id > 0 && $password !== "" && strlen($password) < 6) {
        $error = "Password baru minimal 6 karakter.";
    } else {
        if ($id > 0) {
            if ($password !== "") {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = mysqli_prepare($conn, "UPDATE guru SET nama=?, username=?, password=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, "sssi", $nama, $username, $hash, $id);
            } else {
                $stmt = mysqli_prepare($conn, "UPDATE guru SET nama=?, username=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, "ssi", $nama, $username, $id);
            }
            $ok = "edit";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conn, "INSERT INTO guru (nama, username, password) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "sss", $nama, $username, $hash);
            $ok = "tambah";
        }
        mysqli_stmt_execute($stmt);
        header("Location: pengguna.php?ok=$ok");
        exit;
    }
}
$edit = $data['id'] !== '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $edit ? 'Edit' : 'Tambah' ?> Guru — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1><?= $edit ? 'Edit' : 'Tambah' ?> Akun Guru</h1>
    <?php if ($error) { ?><div class="alert err"><?= $error ?></div><?php } ?>
    <form method="post">
        <input type="hidden" name="id" value="<?= $data['id'] ?>">

        <label>Nama Guru</label>
        <input type="text" name="nama" value="<?= htmlspecialchars($data['nama']) ?>" required>

        <label>Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($data['username']) ?>" required>

        <label>Password<?= $edit ? ' (kosongkan jika tidak diganti)' : '' ?></label>
        <input type="password" name="password" minlength="6" <?= $edit ? '' : 'required' ?>>

        <br><br>
        <button type="submit">Simpan</button>
        <a href="pengguna.php" class="btn abu">Batal</a>
    </form>
</div>
</body>
</html>
