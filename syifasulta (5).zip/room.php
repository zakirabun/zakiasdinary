<?php
session_start();
include "koneksi.php";
include "fungsi.php";

$id = (int) ($_GET['id'] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT e.*, (SELECT COUNT(*) FROM pendaftar p WHERE p.ekskul_id = e.id) AS terisi FROM ekskul e WHERE e.id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$e = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if (!$e) { header("Location: index.php"); exit; }

if (!boleh_akses_room($conn, $id)) {
    if (!isset($_SESSION['role'])) {
        header("Location: login.php?next=" . rawurlencode("room.php?id=$id"));
        exit;
    }

    http_response_code(403);
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Galeri khusus anggota — Clubify</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
    <main class="container">
        <section class="gallery-denied">
            <span class="denied-lock" aria-hidden="true">⌑</span>
            <span class="eyebrow">RUANG PRIVAT ANGGOTA</span>
            <h1>Galeri ini khusus anggota <span class="text-gradient"><?= htmlspecialchars($e['nama']) ?></span></h1>
            <p>Momen di dalam galeri hanya dapat dilihat oleh anggota ekskul, admin, dan guru.</p>
            <div class="denied-actions"><a class="btn" href="daftar.php?id=<?= $id ?>">Daftar ekskul ini</a><a class="btn abu" href="index.php">Kembali ke Clubify</a></div>
        </section>
    </main>
    </body>
    </html>
    <?php
    exit;
}

$stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total,
                                      SUM(tipe = 'foto') AS foto,
                                      SUM(tipe = 'video') AS video,
                                      SUM(tipe = 'musik') AS musik
                               FROM media WHERE ekskul_id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$ringkasanMedia = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

$login = isset($_SESSION['role']);
$bisa_upload = $login && boleh_upload_room($conn, $id);
$kembali = !$login ? 'index.php' : ($_SESSION['role'] === 'siswa' ? 'profil.php' : 'admin.php');

$tipe = $_GET['tipe'] ?? '';
if (in_array($tipe, ['foto', 'video', 'musik'], true)) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM media WHERE ekskul_id = ? AND tipe = ? ORDER BY tanggal DESC");
    mysqli_stmt_bind_param($stmt, "is", $id, $tipe);
} else {
    $tipe = '';
    $stmt = mysqli_prepare($conn, "SELECT * FROM media WHERE ekskul_id = ? ORDER BY tanggal DESC");
    mysqli_stmt_bind_param($stmt, "i", $id);
}
mysqli_stmt_execute($stmt);
$hasil = mysqli_stmt_get_result($stmt);

$teks = ['up' => 'Berhasil diunggah ke room.', 'hapus' => 'Media berhasil dihapus.'];
$pesan = $teks[$_GET['ok'] ?? ''] ?? "";
$q = "room.php?id=$id";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Galeri <?= htmlspecialchars($e['nama']) ?> — Clubify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="nav">
        <a href="index.php" class="brand-mark"><span class="brand-symbol">C</span><span>Clubify</span></a>
        <span class="nav-spacer"></span>
        <a href="index.php" class="btn abu">Semua ekskul</a>
        <?php if ($bisa_upload) { ?><a href="upload.php?ekskul=<?= $id ?>" class="btn edit">+ Bagikan momen</a><?php } ?>
    </div>

    <?php if ($pesan) { ?><div class="alert ok"><?= $pesan ?></div><?php } ?>
    <?php if ($login && $_SESSION['role'] === 'siswa' && !$bisa_upload) { ?>
        <div class="alert err">Kamu belum terdaftar di ekskul ini, jadi belum bisa upload. <a href="daftar.php?id=<?= $id ?>">Daftar dulu</a>.</div>
    <?php } ?>

    <section class="gallery-hero">
        <div class="gallery-hero-copy">
            <a class="gallery-back" href="<?= $kembali ?>">← Kembali</a>
            <span class="eyebrow"><span class="eyebrow-dot"></span> CERITA DARI KEGIATAN</span>
            <h1>Galeri <span class="text-gradient"><?= htmlspecialchars($e['nama']) ?></span></h1>
            <p class="gallery-description">Momen, karya, dan keseruan yang dibagikan oleh anggota <?= htmlspecialchars($e['nama']) ?>.</p>
            <div class="gallery-meta"><span>◷ <?= htmlspecialchars($e['jadwal']) ?></span><span>♧ <?= htmlspecialchars($e['pembina']) ?></span><span>◎ <?= (int) $e['terisi'] ?> anggota</span></div>
        </div>
        <div class="gallery-summary" aria-label="Ringkasan galeri">
            <strong><?= (int) $ringkasanMedia['total'] ?></strong><span>momen dibagikan</span>
            <div><span>▧ <?= (int) $ringkasanMedia['foto'] ?> foto</span><span>▷ <?= (int) $ringkasanMedia['video'] ?> video</span><span>♫ <?= (int) $ringkasanMedia['musik'] ?> audio</span></div>
        </div>
    </section>

    <div class="nav gallery-filters">
        <a href="<?= $q ?>" class="btn <?= $tipe === '' ? '' : 'abu' ?>">Semua <span class="filter-count"><?= (int) $ringkasanMedia['total'] ?></span></a>
        <a href="<?= $q ?>&tipe=foto" class="btn <?= $tipe === 'foto' ? '' : 'abu' ?>">Foto <span class="filter-count"><?= (int) $ringkasanMedia['foto'] ?></span></a>
        <a href="<?= $q ?>&tipe=video" class="btn <?= $tipe === 'video' ? '' : 'abu' ?>">Video <span class="filter-count"><?= (int) $ringkasanMedia['video'] ?></span></a>
        <a href="<?= $q ?>&tipe=musik" class="btn <?= $tipe === 'musik' ? '' : 'abu' ?>">Audio <span class="filter-count"><?= (int) $ringkasanMedia['musik'] ?></span></a>
    </div>

    <div class="grid gallery-grid">
        <?php $ada = false; while ($m = mysqli_fetch_assoc($hasil)) { $ada = true;
            $src = "media_file.php?id=" . (int) $m['id']; ?>
        <article class="card gallery-card">
            <?php if ($m['tipe'] === 'foto') { ?>
                <a class="gallery-image-link" href="<?= $src ?>" target="_blank" rel="noopener" data-lightbox-title="<?= htmlspecialchars($m['judul'], ENT_QUOTES, 'UTF-8') ?>"><img class="gallery-image" src="<?= $src ?>" alt="<?= htmlspecialchars($m['judul']) ?>" loading="lazy"><span class="image-zoom" aria-hidden="true">↗ Perbesar</span></a>
            <?php } elseif ($m['tipe'] === 'video') { ?>
                <div class="video-stage"><video class="media gallery-video" src="<?= $src ?>" controls playsinline preload="metadata"></video><span class="video-badge"><span aria-hidden="true">▶</span> VIDEO KEGIATAN</span><p class="media-error" hidden>Video ini tidak bisa diputar. Periksa format dan file videonya.</p></div>
            <?php } else { ?>
                <div class="audio-player" data-audio-player>
                    <div class="audio-art" aria-hidden="true"><span>♫</span><div class="audio-wave" aria-hidden="true"></div></div>
                    <audio class="gallery-audio" src="<?= $src ?>" controls preload="metadata"></audio>
                    <div class="audio-controls" hidden>
                        <button class="audio-toggle" type="button" aria-label="Putar audio"><span class="audio-toggle-icon" aria-hidden="true">▶</span><span class="audio-toggle-label">Putar</span></button>
                        <div class="audio-progress"><span class="audio-current">0:00</span><input type="range" min="0" max="1000" value="0" aria-label="Posisi audio"><span class="audio-duration">--:--</span></div>
                        <p class="media-error" hidden>Audio ini tidak bisa diputar. Periksa format dan file audionya.</p>
                    </div>
                </div>
            <?php } ?>
            <div class="gallery-card-info">
                <div><span class="media-type"><?= ucfirst($m['tipe'] === 'musik' ? 'audio' : $m['tipe']) ?></span><h3><?= htmlspecialchars($m['judul']) ?></h3>
                <p class="meta">oleh <?= htmlspecialchars($m['pengunggah']) ?> &middot; <?= date('d M Y', strtotime($m['tanggal'])) ?></p></div>
                <?php if (boleh_hapus_media($m)) { ?>
            <form method="post" action="media_hapus.php" class="inline" onsubmit="return confirm('Hapus media ini?')">
                <input type="hidden" name="id" value="<?= $m['id'] ?>">
                <input type="hidden" name="room" value="<?= $id ?>">
                <button type="submit" class="btn hapus" aria-label="Hapus <?= htmlspecialchars($m['judul']) ?>">Hapus</button>
            </form>
                <?php } ?>
            </div>
        </article>
        <?php } ?>
        <?php if (!$ada) { ?>
            <div class="gallery-empty"><span aria-hidden="true">✧</span><h2><?= $tipe ? 'Belum ada ' . htmlspecialchars($tipe === 'musik' ? 'audio' : $tipe) : 'Belum ada momen di galeri' ?></h2><p>Galeri ini akan bertambah seru saat anggota mulai membagikan kegiatan mereka.</p>
                <?php if ($bisa_upload) { ?><a href="upload.php?ekskul=<?= $id ?>" class="btn">Jadilah yang pertama berbagi <span aria-hidden="true">→</span></a><?php } elseif (!$login) { ?><a href="login.php" class="btn">Masuk untuk berbagi</a><?php } ?>
            </div>
        <?php } ?>
    </div>
    <dialog class="photo-lightbox" id="photo-lightbox" aria-label="Foto galeri">
        <form method="dialog"><button class="lightbox-close" aria-label="Tutup foto">×</button></form>
        <img src="" alt="">
        <p></p>
    </dialog>
</div>
<script src="gallery.js" defer></script>
</body>
</html>
